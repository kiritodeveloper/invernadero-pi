/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 * @module highcharts/indicators/psar
 * @requires highcharts
 * @requires highcharts/modules/stock
 *
 * Parabolic SAR Indicator for Highstock
 *
 * (c) 2010-2019 Grzegorz Blachliński
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../indicators/psar.src.js';
